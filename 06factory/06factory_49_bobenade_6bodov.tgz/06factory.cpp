//
// Created by bobenade on 11/11/2025.
//


#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#include <vector>

using namespace std;

// arrays for operation times
int op_times[7];

// production sequences
int prod_seq[3][6] = {
    {0, 1, 2, 3, 1, 4},
    {1, 0, 6, 1, 4, 5},
    {6, 1, 5, 1, 6, 4}
};

const char *wp_names[7] = {"nuzky", "vrtacka", "ohybacka", "svarecka", "lakovna", "sroubovak", "freza"};

struct Job {
    int type;
    int phase;
    Job() : type(-1), phase(-1) {}
    Job(int t, int p) : type(t), phase(p) {}
};

struct Person {
    pthread_t thread;
    char *name;
    int workplace;
    bool should_stop;
    bool is_working;
};

struct Workstation {
    int id;
    const char *name;
    int available;
    int occupied;
};

struct Plant {
    Workstation *ws[7];
    vector<Person*> people;
    int items[3][6];
    int queue[3][6];
    bool shutdown;
};

pthread_cond_t signal_var;
pthread_mutex_t global_lock;
Plant *plant;

int string_to_wp(const char *s) {
    for (int i = 0; i < 7; i++) {
        if (strcmp(s, wp_names[i]) == 0) return i;
    }
    return -1;
}

int string_to_prod(char *s) {
    if (s[0] == 'A') return 0;
    if (s[0] == 'B') return 1;
    if (s[0] == 'C') return 2;
    return -1;
}

void setup_times() {
    op_times[0] = 100000;
    op_times[1] = 200000;
    op_times[2] = 150000;
    op_times[3] = 300000;
    op_times[4] = 400000;
    op_times[5] = 250000;
    op_times[6] = 500000;
}

// try get job for person
Job try_get_job(Person *p) {
    // start from end phases
    int phase = 5;
    while (phase >= 0) {
        int prod = 0;
        while (prod < 3) {
            int needed_wp = prod_seq[prod][phase];
            bool wp_match = (p->workplace == needed_wp);
            bool has_queue = (plant->queue[prod][phase] > 0);
            bool wp_free = (plant->ws[p->workplace]->available > plant->ws[p->workplace]->occupied);

            if (has_queue && wp_match && wp_free) {
                plant->queue[prod][phase]--;
                plant->ws[p->workplace]->occupied++;
                return Job(prod, phase);
            }
            prod++;
        }
        phase--;
    }
    return Job();
}

// check if phase can be reached
bool phase_reachable(int prod, int target_phase) {
    int check_phase = 0;
    while (check_phase < target_phase) {
        int req_wp = prod_seq[prod][check_phase];
        bool found_person = false;

        int i = 0;
        while (i < (int)plant->people.size()) {
            Person *other = plant->people[i];
            if (other->workplace == req_wp && !other->should_stop) {
                if (plant->ws[req_wp]->available > 0) {
                    found_person = true;
                    break;
                }
            }
            i++;
        }

        if (!found_person) return false;
        check_phase++;
    }
    return true;
}

// check if person has work in future
bool has_work_ahead(Person *p) {
    int prod = 0;
    while (prod < 3) {
        int phase = 0;
        while (phase < 6) {
            bool is_my_wp = (p->workplace == prod_seq[prod][phase]);
            bool items_exist = (plant->items[prod][phase] > 0);

            if (items_exist && is_my_wp) {
                if (phase_reachable(prod, phase)) {
                    return true;
                }
            }
            phase++;
        }
        prod++;
    }
    return false;
}

// decide if person leaves
bool decide_leave(Person *p) {
    if (p->should_stop) return true;
    if (!plant->shutdown) return false;

    bool work = has_work_ahead(p);
    return !work;
}

void *person_function(void *arg) {
    Person *me = (Person*)arg;

    int loop = 1;
    while (loop) {
        pthread_mutex_lock(&global_lock);

        bool should_leave = decide_leave(me);
        if (should_leave) {
            printf("%s goes home\n", me->name);
            pthread_mutex_unlock(&global_lock);
            return NULL;
        }

        Job j = try_get_job(me);

        bool got_job = (j.type != -1 && j.phase != -1);
        if (!got_job) {
            if (decide_leave(me)) {
                printf("%s goes home\n", me->name);
                pthread_mutex_unlock(&global_lock);
                return NULL;
            }
            pthread_cond_wait(&signal_var, &global_lock);
            pthread_mutex_unlock(&global_lock);
            continue;
        }

        // print work info
        Workstation *my_ws = plant->ws[me->workplace];
        char prod_letter = (char)(j.type + 65);
        printf("%s %s %d %c\n", me->name, my_ws->name, j.phase + 1, prod_letter);

        me->is_working = true;
        pthread_mutex_unlock(&global_lock);

        // simulate work
        usleep(op_times[me->workplace]);

        pthread_mutex_lock(&global_lock);
        me->is_working = false;
        plant->ws[me->workplace]->occupied--;
        plant->items[j.type][j.phase]--;

        bool is_last_phase = (j.phase == 5);
        if (is_last_phase) {
            printf("done %c\n", prod_letter);
        } else {
            plant->queue[j.type][j.phase + 1]++;
        }

        pthread_cond_broadcast(&signal_var);
        pthread_mutex_unlock(&global_lock);
    }

    return NULL;
}

bool check_work_exists() {
    int i = 0;
    while (i < 3) {
        int j = 0;
        while (j < 6) {
            if (plant->items[i][j] > 0) return true;
            if (plant->queue[i][j] > 0) return true;
            j++;
        }
        i++;
    }
    return false;
}

bool check_can_proceed() {
    int prod = 0;
    while (prod < 3) {
        int phase = 0;
        while (phase < 6) {
            bool has_items = (plant->items[prod][phase] > 0);
            bool has_queue = (plant->queue[prod][phase] > 0);

            if (has_items || has_queue) {
                int req_wp = prod_seq[prod][phase];
                bool found = false;

                int i = 0;
                while (i < (int)plant->people.size()) {
                    Person *p = plant->people[i];
                    bool not_leaving = !p->should_stop;
                    bool right_wp = (p->workplace == req_wp);
                    bool wp_exists = (plant->ws[req_wp]->available > 0);

                    if (not_leaving && right_wp && wp_exists) {
                        found = true;
                        break;
                    }
                    i++;
                }

                if (found) return true;
            }
            phase++;
        }
        prod++;
    }
    return false;
}

int main(int argc, char **argv) {
    pthread_cond_init(&signal_var, NULL);
    pthread_mutex_init(&global_lock, NULL);
    setup_times();

    plant = new Plant();
    plant->shutdown = false;

    // setup workstations manually
    int ws_idx = 0;
    while (ws_idx < 7) {
        plant->ws[ws_idx] = new Workstation();
        plant->ws[ws_idx]->id = ws_idx;
        plant->ws[ws_idx]->name = wp_names[ws_idx];
        plant->ws[ws_idx]->available = 0;
        plant->ws[ws_idx]->occupied = 0;
        ws_idx++;
    }

    // init arrays
    int x = 0;
    while (x < 3) {
        int y = 0;
        while (y < 6) {
            plant->items[x][y] = 0;
            plant->queue[x][y] = 0;
            y++;
        }
        x++;
    }

    // main command loop
    int running = 1;
    while (running) {
        char *input_line = NULL;
        int read_result = scanf(" %m[^\n]", &input_line);

        if (read_result == EOF) {
            running = 0;
            break;
        }
        if (read_result == 0) continue;

        char *token_state;
        char *cmd = strtok_r(input_line, " ", &token_state);
        char *arg1 = strtok_r(NULL, " ", &token_state);
        char *arg2 = strtok_r(NULL, " ", &token_state);
        char *arg3 = strtok_r(NULL, " ", &token_state);

        bool is_start = (strcmp(cmd, "start") == 0);
        bool is_make = (strcmp(cmd, "make") == 0);
        bool is_end = (strcmp(cmd, "end") == 0);
        bool is_add = (strcmp(cmd, "add") == 0);
        bool is_remove = (strcmp(cmd, "remove") == 0);

        if (is_start && arg1 && arg2 && !arg3) {
            pthread_mutex_lock(&global_lock);
            int wp_id = string_to_wp(arg2);
            if (wp_id >= 0) {
                Person *new_person = new Person();
                new_person->name = strdup(arg1);
                new_person->workplace = wp_id;
                new_person->should_stop = false;
                new_person->is_working = false;
                pthread_create(&(new_person->thread), NULL, person_function, new_person);
                plant->people.push_back(new_person);
            }
            pthread_mutex_unlock(&global_lock);
        }
        else if (is_make && arg1 && !arg2) {
            pthread_mutex_lock(&global_lock);
            int prod_id = string_to_prod(arg1);
            if (prod_id >= 0) {
                int step = 0;
                while (step < 6) {
                    plant->items[prod_id][step]++;
                    step++;
                }
                plant->queue[prod_id][0]++;
                pthread_cond_broadcast(&signal_var);
            }
            pthread_mutex_unlock(&global_lock);
        }
        else if (is_end && arg1 && !arg2) {
            pthread_mutex_lock(&global_lock);
            int idx = 0;
            while (idx < (int)plant->people.size()) {
                if (strcmp(plant->people[idx]->name, arg1) == 0) {
                    plant->people[idx]->should_stop = true;
                    break;
                }
                idx++;
            }
            pthread_cond_broadcast(&signal_var);
            pthread_mutex_unlock(&global_lock);
        }
        else if (is_add && arg1 && !arg2) {
            pthread_mutex_lock(&global_lock);
            int wp_id = string_to_wp(arg1);
            if (wp_id >= 0) {
                plant->ws[wp_id]->available++;
            }
            pthread_cond_broadcast(&signal_var);
            pthread_mutex_unlock(&global_lock);
        }
        else if (is_remove && arg1 && !arg2) {
            pthread_mutex_lock(&global_lock);
            int wp_id = string_to_wp(arg1);
            if (wp_id >= 0) {
                if (plant->ws[wp_id]->available > 0) {
                    plant->ws[wp_id]->available--;
                }
            }
            pthread_cond_broadcast(&signal_var);
            pthread_mutex_unlock(&global_lock);
        }
        else {
            fprintf(stderr, "Invalid command: %s\n", input_line);
        }

        free(input_line);
    }

    pthread_mutex_lock(&global_lock);
    plant->shutdown = true;

    bool continue_loop = true;
    while (continue_loop) {
        bool exists = check_work_exists();
        bool can_do = check_can_proceed();

        if (!exists || !can_do) {
            continue_loop = false;
            break;
        }

        pthread_cond_broadcast(&signal_var);
        pthread_cond_wait(&signal_var, &global_lock);
    }

    int i = 0;
    while (i < (int)plant->people.size()) {
        plant->people[i]->should_stop = true;
        i++;
    }
    pthread_cond_broadcast(&signal_var);
    pthread_mutex_unlock(&global_lock);

    // join threads
    int j = 0;
    while (j < (int)plant->people.size()) {
        pthread_join(plant->people[j]->thread, NULL);
        j++;
    }

    // cleanup
    int k = 0;
    while (k < 7) {
        delete plant->ws[k];
        k++;
    }

    int m = 0;
    while (m < (int)plant->people.size()) {
        free(plant->people[m]->name);
        delete plant->people[m];
        m++;
    }

    delete plant;

    pthread_cond_destroy(&signal_var);
    pthread_mutex_destroy(&global_lock);

    return 0;
}